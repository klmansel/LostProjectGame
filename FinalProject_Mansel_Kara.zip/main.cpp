#include "Game.hpp"
#include <iostream>



int main(){

  //create new Game object
  Game hauntedMansion;
  //run start menu for Haunted Mansion Game
  hauntedMansion.startMenu();

  return 0;
}
